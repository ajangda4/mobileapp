import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './screens/HomeScreen.jsx'; // Ensure path is correct
import ContributorsScreen from './screens/ContributorScreen.jsx'; // Ensure path matches the file
import ProjectScreen from './screens/ProjectScreen.jsx'; // Corrected relative path
import APIFeatureScreen from './screens/APIFeatureScreen.jsx'; // Ensure path is correct

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Contributors" component={ContributorsScreen} />
        <Stack.Screen name="Project" component={ProjectScreen} />
        <Stack.Screen name="API Feature" component={APIFeatureScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
