import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Linking } from 'react-native';

export default function ProjectScreen() {
  const openWebsite = () => {
    Linking.openURL('https://github.com/HammadMal/Web-and-Mobile-Development-Milestone-2-'); // Replace with your project's URL
  };

  return (
    <View style={styles.container}>
      <Image
        source={{
          uri: 'https://via.placeholder.com/300x200?text=SchedUTrack', // Replace with your project image URL
        }}
        style={styles.image}
      />
      <Text style={styles.title}>SchedUTrack</Text>
      <Text style={styles.subtitle}>Your Personalized Academic Planner</Text>
      <Text style={styles.description}>
        SchedUTrack is a comprehensive website designed to simplify student life, similar to Stellic. Upon logging in, students gain access to an intuitive dashboard displaying their courses, tasks, grades, and attendance. The platform also empowers students to design their schedule for the upcoming semester and manage tasks effortlessly, ensuring a seamless academic experience.
      </Text>
      <TouchableOpacity style={styles.button} onPress={openWebsite}>
        <Text style={styles.buttonText}>Visit Project Website</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eef2f3',
    padding: 20,
    alignItems: 'center',
  },
  image: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    color: '#7f8c8d',
    marginBottom: 20,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  description: {
    fontSize: 16,
    color: '#34495e',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#e74c3c', // Eye-catching red button
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
