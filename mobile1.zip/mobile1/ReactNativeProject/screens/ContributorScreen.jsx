import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function ContributerScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Meet the Contributors</Text>
      
      <View style={styles.card}>
        <Image 
          source={{ uri: 'https://via.placeholder.com/100' }} 
          style={styles.image} 
        />
        <Text style={styles.name}>1. Arsal Jangda</Text>
        <Text style={styles.role}>Student</Text>
      </View>

      <View style={styles.card}>
        <Image 
          source={{ uri: 'https://via.placeholder.com/100' }} 
          style={styles.image} 
        />
        <Text style={styles.name}>2. Hammad Malik</Text>
        <Text style={styles.role}>Student</Text>
      </View>

      <View style={styles.card}>
        <Image 
          source={{ uri: 'https://via.placeholder.com/100' }} 
          style={styles.image} 
        />
        <Text style={styles.name}>3. Mustafa Qazi</Text>
        <Text style={styles.role}>Student</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#eef2f3',
    paddingVertical: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
    width: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#34495e',
  },
  role: {
    fontSize: 16,
    color: '#7f8c8d',
    marginTop: 5,
  },
});
