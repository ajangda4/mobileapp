import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to SchedUTrack</Text>
      <Text style={styles.subtitle}>
        Your Personalized Academic Planner  
      </Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Contributors')}
      >
        <Text style={styles.buttonText}>Meet the Contributors</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Project')}
      >
        <Text style={styles.buttonText}>Project Details</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('API Feature')}
      >
        <Text style={styles.buttonText}>Explore API Features</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#eef2f3', // Subtle light background
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2c3e50', // Dark modern color
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#7f8c8d', // Subtle gray for subtitle
    marginBottom: 30,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#3498db', // Modern blue color
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25, // Rounded buttons
    marginVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 5, // Shadow for Android
  },
  buttonText: {
    color: '#fff', // White text for contrast
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
